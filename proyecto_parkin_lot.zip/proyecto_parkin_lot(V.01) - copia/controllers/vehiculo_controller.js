// importar el modulo vehiculo
const vehiculo = require("../models/vehiculo");

// Validar el metodo create/crear vehiculo
const create = async (req, res) => {
  try {
    const { placa, color, modelo, marca, tipo, id_usuario } = req.body;

    if (!placa || !color || !modelo || !marca || !tipo || !id_usuario) {
      return res.status(400).json({
        success: false,
        message: "Todos los campos requeridos deben ser proporcionados",
      });
    }

    const modelo_vehiculo = await vehiculo.create({
      placa,
      color,
      modelo,
      marca,
      tipo,
      id_usuario,
    }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Vehiculo registrado exitosamente",
      data: modelo_vehiculo,
    });
  } catch (error) {
    console.error("Error al crear vehiculo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los vehiculos
const findAll = async (req, res) => {
  try {
    const vehiculos = await vehiculo.findAll();
    res.status(200).json({
      success: true,
      message: "Vehiculos obtenidos exitosamente",
      data: vehiculos,
    });
  } catch (error) {
    console.error("Error al obtener vehiculo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener vehiculo por ID
const findById = async (req, res) => {
  try {
    const { id_vehiculo } = req.params;
    if (!id_vehiculo) {
      return res.status(400).json({
        success: false,
        message: "El id del vehiculo es requerido",
      });
    }

    const vehiculoEncontrado = await vehiculo.findById(id_vehiculo);

    if (!vehiculoEncontrado) {
      return res.status(404).json({
        success: false,
        message: "Vehiculo no encontrado",
      });
    }

    res.status(200).json({
      success: true,
      message: "Vehiculo obtenido exitosamente",
      data: vehiculoEncontrado,
    });
  } catch (error) {
    console.error("Error al obtener vehiculo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener vehiculo por placa
const searchByPlaca = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const vehiculos = await vehiculo.searchByPlaca(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de vehiculos por: "${term}"`,
      data: vehiculos,
    });
  } catch (error) {
    console.error("Error al buscar vehiculos: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar vehiculo
const update = async (req, res) => {
  try {
    const { id_vehiculo } = req.params;
    const { placa, color, modelo, marca, tipo, id_usuario } = req.body;

    if (!id_vehiculo) {
      return res.status(404).json({
        success: false,
        message: "El id del vehiculo no existe",
      });
    }

    // Verificar que el vehiculo exista
    const vehiculoEncontrado = await vehiculo.findById(id_vehiculo);
    if (!vehiculoEncontrado) {
      return res.status(404).json({
        success: false,
        message: "Vehiculo no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const vehiculoUpdated = await vehiculo.update(id_vehiculo, {
      placa,
      color,
      modelo,
      marca,
      tipo,
      id_usuario,
    });

    res.status(200).json({
      success: true,
      message: "Vehiculo actualizado exitosamente",
      data: vehiculoUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar vehiculo:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un vehiculo
const deleteVehiculo = async (req, res) => {
  try {
    const { id_vehiculo } = req.params;

    if (!id_vehiculo) {
      return res.status(404).json({
        success: false,
        message: "El vehiculo no existe",
      });
    }

    // Verificar que el vehiculo exista
    const vehiculoEncontrado = await vehiculo.findById(id_vehiculo);
    if (!vehiculoEncontrado) {
      return res.status(404).json({
        success: false,
        message: "Vehiculo no encontrado",
      });
    }

    await vehiculo.delete(id_vehiculo);

    res.status(200).json({
      success: true,
      message: "Vehiculo eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un vehiculo:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByPlaca,
  update,
  deleteVehiculo,
};
