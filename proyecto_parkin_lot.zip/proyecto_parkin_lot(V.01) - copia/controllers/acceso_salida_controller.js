// importar el modulo acceso_salida
const acceso_salida = require("../models/acceso_salida");
// importar modelos relacionados
const celda = require("../models/celda");
const historial_parqueo = require("../models/historial_parqueo");

// Validar el metodo create/crear acceso_salida
const create = async (req, res) => {
  try {
    const { movimiento, fecha_hora, puerta, id_vehiculo } = req.body;

    if (!movimiento || !fecha_hora || !puerta || !id_vehiculo) {
      return res.status(400).json({
        success: false,
        message: "Movimiento, fecha_hora, puerta e id_vehiculo son requeridos",
      });
    }

    let tiempo_estadia = "0"; // default for entrada
    let assignedCelda = null;

    if (movimiento === "entrada") {
      // Buscar celda disponible
      const availableCelda = await celda.findOne({ estado: "libre" });
      if (!availableCelda) {
        return res.status(400).json({
          success: false,
          message: "No hay celdas disponibles",
        });
      }

      // Actualizar celda a ocupada
      await celda.update(availableCelda.id_celda, { estado: "ocupada" });

      // Crear historial_parqueo
      await historial_parqueo.create({
        id_celda: availableCelda.id_celda,
        id_vehiculo,
        fecha_hora,
      });

      assignedCelda = availableCelda.id_celda;
      tiempo_estadia = "0";
    } else if (movimiento === "salida") {
      // Encontrar el último historial_parqueo para el vehículo
      const historial = await historial_parqueo
        .findOne({ id_vehiculo })
        .sort({ fecha_hora: -1 });
      if (!historial) {
        return res.status(400).json({
          success: false,
          message: "No se encontró registro de entrada para este vehículo",
        });
      }

      // Calcular tiempo de estadía
      const entryTime = new Date(historial.fecha_hora);
      const exitTime = new Date(fecha_hora);
      const diffMs = exitTime - entryTime;
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      tiempo_estadia = `${diffHours}h ${diffMinutes}m`;

      // Actualizar celda a libre
      await celda.update(historial.id_celda, { estado: "libre" });

      // Eliminar historial_parqueo
      await historial_parqueo.delete(historial.id_historial_parqueo);

      assignedCelda = historial.id_celda;
    } else {
      return res.status(400).json({
        success: false,
        message: "Movimiento debe ser 'entrada' o 'salida'",
      });
    }

    const modelo_acceso_salida = await acceso_salida.create({
      movimiento,
      fecha_hora,
      puerta,
      tiempo_estadia,
      id_vehiculo,
      id_celda: assignedCelda,
    }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Acceso salida registrado exitosamente",
      data: modelo_acceso_salida,
    });
  } catch (error) {
    console.error("Error al crear acceso_salida: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los acceso_salida
const findAll = async (req, res) => {
  try {
    const accesos_salida = await acceso_salida.findAll();
    res.status(200).json({
      success: true,
      message: "Accesos salida obtenidos exitosamente",
      data: accesos_salida,
    });
  } catch (error) {
    console.error("Error al obtener acceso_salida: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener acceso_salida por ID
const findById = async (req, res) => {
  try {
    const { id_acceso_salida } = req.params;
    if (!id_acceso_salida) {
      return res.status(400).json({
        success: false,
        message: "El id del acceso salida es requerido",
      });
    }

    const accesoSalida = await acceso_salida.findById(id_acceso_salida);

    if (!accesoSalida) {
      return res.status(404).json({
        success: false,
        message: "Acceso salida no encontrado",
      });
    }

    res.status(200).json({
      success: true,
      message: "Acceso salida obtenido exitosamente",
      data: accesoSalida,
    });
  } catch (error) {
    console.error("Error al obtener acceso salida: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener acceso_salida por movimiento
const searchByMovimiento = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const accesos_salida = await acceso_salida.searchByMovimiento(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de accesos salida por: "${term}"`,
      data: accesos_salida,
    });
  } catch (error) {
    console.error("Error al buscar accesos salida: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar acceso_salida
const update = async (req, res) => {
  try {
    const { id_acceso_salida } = req.params;
    const { movimiento, fecha_hora, puerta, tiempo_estadia, id_vehiculo } =
      req.body;

    if (!id_acceso_salida) {
      return res.status(404).json({
        success: false,
        message: "El id del acceso salida no existe",
      });
    }

    // Verificar que el acceso_salida exista
    const accesoSalida = await acceso_salida.findById(id_acceso_salida);
    if (!accesoSalida) {
      return res.status(404).json({
        success: false,
        message: "Acceso salida no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const accesoSalidaUpdated = await acceso_salida.update(id_acceso_salida, {
      movimiento,
      fecha_hora,
      puerta,
      tiempo_estadia,
      id_vehiculo,
    });

    res.status(200).json({
      success: true,
      message: "Acceso salida actualizado exitosamente",
      data: accesoSalidaUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar acceso salida:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un acceso_salida
const deleteAccesoSalida = async (req, res) => {
  try {
    const { id_acceso_salida } = req.params;

    if (!id_acceso_salida) {
      return res.status(404).json({
        success: false,
        message: "El acceso salida no existe",
      });
    }

    // Verificar que el acceso_salida exista
    const accesoSalida = await acceso_salida.findById(id_acceso_salida);
    if (!accesoSalida) {
      return res.status(404).json({
        success: false,
        message: "Acceso salida no encontrado",
      });
    }

    await acceso_salida.delete(id_acceso_salida);

    res.status(200).json({
      success: true,
      message: "Acceso salida eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un acceso salida:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByMovimiento,
  update,
  deleteAccesoSalida,
};
