// importar el modulo celda
const celda = require("../models/celda");

// Validar el metodo create/crear celda
const create = async (req, res) => {
  try {
    const { tipo, estado } = req.body;

    if (!tipo || !estado) {
      return res.status(400).json({
        success: false,
        message: "Todos los campos requeridos deben ser proporcionados",
      });
    }

    const modelo_celda = await celda.create({ tipo, estado }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Celda registrada exitosamente",
      data: modelo_celda,
    });
  } catch (error) {
    console.error("Error al crear celda: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los celdas
const findAll = async (req, res) => {
  try {
    const celdas = await celda.findAll();
    res.status(200).json({
      success: true,
      message: "Celdas obtenidas exitosamente",
      data: celdas,
    });
  } catch (error) {
    console.error("Error al obtener celda: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener celda por ID
const findById = async (req, res) => {
  try {
    const { id_celda } = req.params;
    if (!id_celda) {
      return res.status(400).json({
        success: false,
        message: "El id de la celda es requerido",
      });
    }

    const celdaEncontrada = await celda.findById(id_celda);

    if (!celdaEncontrada) {
      return res.status(404).json({
        success: false,
        message: "Celda no encontrada",
      });
    }

    res.status(200).json({
      success: true,
      message: "Celda obtenida exitosamente",
      data: celdaEncontrada,
    });
  } catch (error) {
    console.error("Error al obtener celda: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener celda por tipo
const searchByTipo = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const celdas = await celda.searchByTipo(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de celdas por: "${term}"`,
      data: celdas,
    });
  } catch (error) {
    console.error("Error al buscar celdas: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar celda
const update = async (req, res) => {
  try {
    const { id_celda } = req.params;
    const { tipo, estado } = req.body;

    if (!id_celda) {
      return res.status(404).json({
        success: false,
        message: "El id de la celda no existe",
      });
    }

    // Verificar que la celda exista
    const celdaEncontrada = await celda.findById(id_celda);
    if (!celdaEncontrada) {
      return res.status(404).json({
        success: false,
        message: "Celda no encontrada",
      });
    }

    // Invocar el metodo Update del modelo
    const celdaUpdated = await celda.update(id_celda, {
      tipo,
      estado,
    });

    res.status(200).json({
      success: true,
      message: "Celda actualizada exitosamente",
      data: celdaUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar celda:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un celda
const deleteCelda = async (req, res) => {
  try {
    const { id_celda } = req.params;

    if (!id_celda) {
      return res.status(404).json({
        success: false,
        message: "La celda no existe",
      });
    }

    // Verificar que la celda exista
    const celdaEncontrada = await celda.findById(id_celda);
    if (!celdaEncontrada) {
      return res.status(404).json({
        success: false,
        message: "Celda no encontrada",
      });
    }

    await celda.delete(id_celda);

    res.status(200).json({
      success: true,
      message: "Celda eliminada exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar una celda:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByTipo,
  update,
  deleteCelda,
};
