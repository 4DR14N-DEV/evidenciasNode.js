// importar el modulo reporte_incidencia
const reporte_incidencia = require("../models/reporte_incidencia");

// Validar el metodo create/crear reporte_incidencia
const create = async (req, res) => {
  try {
    const { id_vehiculo, id_incidencia, fecha_hora } = req.body;

    if (!id_vehiculo || !id_incidencia || !fecha_hora) {
      return res.status(400).json({
        success: false,
        message: "Todos los campos requeridos deben ser proporcionados",
      });
    }

    const modelo_reporte_incidencia = await reporte_incidencia.create({
      id_vehiculo,
      id_incidencia,
      fecha_hora,
    }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Reporte incidencia registrado exitosamente",
      data: modelo_reporte_incidencia,
    });
  } catch (error) {
    console.error("Error al crear reporte_incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los reporte_incidencia
const findAll = async (req, res) => {
  try {
    const reportes_incidencia = await reporte_incidencia.findAll();
    res.status(200).json({
      success: true,
      message: "Reportes incidencia obtenidos exitosamente",
      data: reportes_incidencia,
    });
  } catch (error) {
    console.error("Error al obtener reporte_incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener reporte_incidencia por ID
const findById = async (req, res) => {
  try {
    const { id_reporte_incidencia } = req.params;
    if (!id_reporte_incidencia) {
      return res.status(400).json({
        success: false,
        message: "El id del reporte incidencia es requerido",
      });
    }

    const reporteIncidencia = await reporte_incidencia.findById(
      id_reporte_incidencia
    );

    if (!reporteIncidencia) {
      return res.status(404).json({
        success: false,
        message: "Reporte incidencia no encontrado",
      });
    }

    res.status(200).json({
      success: true,
      message: "Reporte incidencia obtenido exitosamente",
      data: reporteIncidencia,
    });
  } catch (error) {
    console.error("Error al obtener reporte incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener reporte_incidencia por fecha_hora
const searchByFechaHora = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const reportes_incidencia = await reporte_incidencia.searchByFechaHora(
      term
    );

    res.status(200).json({
      success: true,
      message: `Busqueda de reportes incidencia por: "${term}"`,
      data: reportes_incidencia,
    });
  } catch (error) {
    console.error("Error al buscar reportes incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar reporte_incidencia
const update = async (req, res) => {
  try {
    const { id_reporte_incidencia } = req.params;
    const { id_vehiculo, id_incidencia, fecha_hora } = req.body;

    if (!id_reporte_incidencia) {
      return res.status(404).json({
        success: false,
        message: "El id del reporte incidencia no existe",
      });
    }

    // Verificar que el reporte_incidencia exista
    const reporteIncidencia = await reporte_incidencia.findById(
      id_reporte_incidencia
    );
    if (!reporteIncidencia) {
      return res.status(404).json({
        success: false,
        message: "Reporte incidencia no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const reporteIncidenciaUpdated = await reporte_incidencia.update(
      id_reporte_incidencia,
      {
        id_vehiculo,
        id_incidencia,
        fecha_hora,
      }
    );

    res.status(200).json({
      success: true,
      message: "Reporte incidencia actualizado exitosamente",
      data: reporteIncidenciaUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar reporte incidencia:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un reporte_incidencia
const deleteReporteIncidencia = async (req, res) => {
  try {
    const { id_reporte_incidencia } = req.params;

    if (!id_reporte_incidencia) {
      return res.status(404).json({
        success: false,
        message: "El reporte incidencia no existe",
      });
    }

    // Verificar que el reporte_incidencia exista
    const reporteIncidencia = await reporte_incidencia.findById(
      id_reporte_incidencia
    );
    if (!reporteIncidencia) {
      return res.status(404).json({
        success: false,
        message: "Reporte incidencia no encontrado",
      });
    }

    await reporte_incidencia.delete(id_reporte_incidencia);

    res.status(200).json({
      success: true,
      message: "Reporte incidencia eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un reporte incidencia:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByFechaHora,
  update,
  deleteReporteIncidencia,
};
