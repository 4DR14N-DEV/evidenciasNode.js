// importar el modulo usuario
const usuario = require("../models/usuario");

// Validar el metodo create/crear usuario
const create = async (req, res) => {
  try {
    const {
      tipo_documento,
      numero_documento,
      primer_nombre,
      primer_apellido,
      correo,
      estado,
      clave,
      id_perfil_usuario,
    } = req.body;

    if (
      !tipo_documento ||
      !numero_documento ||
      !primer_nombre ||
      !primer_apellido ||
      !correo ||
      !estado ||
      !clave ||
      !id_perfil_usuario
    ) {
      return res.status(400).json({
        success: false,
        message: "Todos los campos requeridos deben ser proporcionados",
      });
    }

    const modelo_usuario = await usuario.create({
      tipo_documento,
      numero_documento,
      primer_nombre,
      primer_apellido,
      correo,
      estado,
      clave,
      id_perfil_usuario,
    }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Usuario registrado exitosamente",
      data: modelo_usuario,
    });
  } catch (error) {
    console.error("Error al crear usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los usuarios
const findAll = async (req, res) => {
  try {
    const usuarios = await usuario.findAll();
    res.status(200).json({
      success: true,
      message: "Usuarios obtenidos exitosamente",
      data: usuarios,
    });
  } catch (error) {
    console.error("Error al obtener usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener usuario por ID
const findById = async (req, res) => {
  try {
    const { id_usuario } = req.params;
    if (!id_usuario) {
      return res.status(400).json({
        success: false,
        message: "El id del usuario es requerido",
      });
    }

    const usuarioEncontrado = await usuario.findById(id_usuario);

    if (!usuarioEncontrado) {
      return res.status(404).json({
        success: false,
        message: "Usuario no encontrado",
      });
    }

    res.status(200).json({
      success: true,
      message: "Usuario obtenido exitosamente",
      data: usuarioEncontrado,
    });
  } catch (error) {
    console.error("Error al obtener usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener usuario por primer_nombre
const searchByPrimerNombre = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const usuarios = await usuario.searchByPrimerNombre(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de usuarios por: "${term}"`,
      data: usuarios,
    });
  } catch (error) {
    console.error("Error al buscar usuarios: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar usuario
const update = async (req, res) => {
  try {
    const { id_usuario } = req.params;
    const {
      tipo_documento,
      numero_documento,
      primer_nombre,
      segundo_nombre,
      primer_apellido,
      segundo_apellido,
      correo,
      numero_celular,
      foto_perfil,
      estado,
      clave,
      id_perfil_usuario,
    } = req.body;

    if (!id_usuario) {
      return res.status(404).json({
        success: false,
        message: "El id del usuario no existe",
      });
    }

    // Verificar que el usuario exista
    const usuarioEncontrado = await usuario.findById(id_usuario);
    if (!usuarioEncontrado) {
      return res.status(404).json({
        success: false,
        message: "Usuario no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const usuarioUpdated = await usuario.update(id_usuario, {
      tipo_documento,
      numero_documento,
      primer_nombre,
      segundo_nombre,
      primer_apellido,
      segundo_apellido,
      correo,
      numero_celular,
      foto_perfil,
      estado,
      clave,
      id_perfil_usuario,
    });

    res.status(200).json({
      success: true,
      message: "Usuario actualizado exitosamente",
      data: usuarioUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar usuario:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Autenticar usuario (login)
const authenticate = async (req, res) => {
  try {
    const { numero_documento, clave } = req.body;

    if (!numero_documento || !clave) {
      return res.status(400).json({
        success: false,
        message: "El número de documento y la clave son requeridos",
      });
    }

    const usuarioAutenticado = await usuario.authenticate(
      numero_documento,
      clave
    );

    if (!usuarioAutenticado) {
      return res.status(401).json({
        success: false,
        message: "Credenciales inválidas o usuario inactivo",
      });
    }

    res.status(200).json({
      success: true,
      message: "Usuario autenticado exitosamente",
      data: usuarioAutenticado,
    });
  } catch (error) {
    console.error("Error al autenticar usuario:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un usuario
const deleteUsuario = async (req, res) => {
  try {
    const { id_usuario } = req.params;

    if (!id_usuario) {
      return res.status(404).json({
        success: false,
        message: "El usuario no existe",
      });
    }

    // Verificar que el usuario exista
    const usuarioEncontrado = await usuario.findById(id_usuario);
    if (!usuarioEncontrado) {
      return res.status(404).json({
        success: false,
        message: "Usuario no encontrado",
      });
    }

    await usuario.delete(id_usuario);

    res.status(200).json({
      success: true,
      message: "Usuario eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un usuario:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByPrimerNombre,
  update,
  deleteUsuario,
  authenticate,
};
