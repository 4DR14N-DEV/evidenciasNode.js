// importar el modulo incidencia
const incidencia = require("../models/incidencia");

// Validar el metodo create/crear incidencia
const create = async (req, res) => {
  try {
    const { nombre } = req.body;

    if (!nombre) {
      return res.status(400).json({
        success: false,
        message: "El nombre es requerido",
      });
    }

    const modelo_incidencia = await incidencia.create({ nombre }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Incidencia registrada exitosamente",
      data: modelo_incidencia,
    });
  } catch (error) {
    console.error("Error al crear incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los incidencias
const findAll = async (req, res) => {
  try {
    const incidencias = await incidencia.findAll();
    res.status(200).json({
      success: true,
      message: "Incidencias obtenidas exitosamente",
      data: incidencias,
    });
  } catch (error) {
    console.error("Error al obtener incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener incidencia por ID
const findById = async (req, res) => {
  try {
    const { id_incidencia } = req.params;
    if (!id_incidencia) {
      return res.status(400).json({
        success: false,
        message: "El id de la incidencia es requerido",
      });
    }

    const incidenciaEncontrada = await incidencia.findById(id_incidencia);

    if (!incidenciaEncontrada) {
      return res.status(404).json({
        success: false,
        message: "Incidencia no encontrada",
      });
    }

    res.status(200).json({
      success: true,
      message: "Incidencia obtenida exitosamente",
      data: incidenciaEncontrada,
    });
  } catch (error) {
    console.error("Error al obtener incidencia: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener incidencia por nombre
const searchByNombre = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const incidencias = await incidencia.searchByNombre(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de incidencias por: "${term}"`,
      data: incidencias,
    });
  } catch (error) {
    console.error("Error al buscar incidencias: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar incidencia
const update = async (req, res) => {
  try {
    const { id_incidencia } = req.params;
    const { nombre } = req.body;

    if (!id_incidencia) {
      return res.status(404).json({
        success: false,
        message: "El id de la incidencia no existe",
      });
    }

    // Verificar que la incidencia exista
    const incidenciaEncontrada = await incidencia.findById(id_incidencia);
    if (!incidenciaEncontrada) {
      return res.status(404).json({
        success: false,
        message: "Incidencia no encontrada",
      });
    }

    // Invocar el metodo Update del modelo
    const incidenciaUpdated = await incidencia.update(id_incidencia, {
      nombre,
    });

    res.status(200).json({
      success: true,
      message: "Incidencia actualizada exitosamente",
      data: incidenciaUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar incidencia:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un incidencia
const deleteIncidencia = async (req, res) => {
  try {
    const { id_incidencia } = req.params;

    if (!id_incidencia) {
      return res.status(404).json({
        success: false,
        message: "La incidencia no existe",
      });
    }

    // Verificar que la incidencia exista
    const incidenciaEncontrada = await incidencia.findById(id_incidencia);
    if (!incidenciaEncontrada) {
      return res.status(404).json({
        success: false,
        message: "Incidencia no encontrada",
      });
    }

    await incidencia.delete(id_incidencia);

    res.status(200).json({
      success: true,
      message: "Incidencia eliminada exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar una incidencia:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByNombre,
  update,
  deleteIncidencia,
};
