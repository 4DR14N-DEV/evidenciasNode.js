// importar el modulo historial_parqueo
const historial_parqueo = require("../models/historial_parqueo");

// Validar el metodo create/crear historial_parqueo
const create = async (req, res) => {
  try {
    const { id_celda, id_vehiculo, fecha_hora } = req.body;

    if (!id_celda || !id_vehiculo || !fecha_hora) {
      return res.status(400).json({
        success: false,
        message: "Todos los campos requeridos deben ser proporcionados",
      });
    }

    const modelo_historial_parqueo = await historial_parqueo.create({
      id_celda,
      id_vehiculo,
      fecha_hora,
    }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Historial parqueo registrado exitosamente",
      data: modelo_historial_parqueo,
    });
  } catch (error) {
    console.error("Error al crear historial_parqueo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los historial_parqueo
const findAll = async (req, res) => {
  try {
    const historiales_parqueo = await historial_parqueo.findAll();
    res.status(200).json({
      success: true,
      message: "Historiales parqueo obtenidos exitosamente",
      data: historiales_parqueo,
    });
  } catch (error) {
    console.error("Error al obtener historial_parqueo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener historial_parqueo por ID
const findById = async (req, res) => {
  try {
    const { id_historial_parqueo } = req.params;
    if (!id_historial_parqueo) {
      return res.status(400).json({
        success: false,
        message: "El id del historial parqueo es requerido",
      });
    }

    const historialParqueo = await historial_parqueo.findById(
      id_historial_parqueo
    );

    if (!historialParqueo) {
      return res.status(404).json({
        success: false,
        message: "Historial parqueo no encontrado",
      });
    }

    res.status(200).json({
      success: true,
      message: "Historial parqueo obtenido exitosamente",
      data: historialParqueo,
    });
  } catch (error) {
    console.error("Error al obtener historial parqueo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener historial_parqueo por fecha_hora
const searchByFechaHora = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const historiales_parqueo = await historial_parqueo.searchByFechaHora(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de historiales parqueo por: "${term}"`,
      data: historiales_parqueo,
    });
  } catch (error) {
    console.error("Error al buscar historiales parqueo: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar historial_parqueo
const update = async (req, res) => {
  try {
    const { id_historial_parqueo } = req.params;
    const { id_celda, id_vehiculo, fecha_hora } = req.body;

    if (!id_historial_parqueo) {
      return res.status(404).json({
        success: false,
        message: "El id del historial parqueo no existe",
      });
    }

    // Verificar que el historial_parqueo exista
    const historialParqueo = await historial_parqueo.findById(
      id_historial_parqueo
    );
    if (!historialParqueo) {
      return res.status(404).json({
        success: false,
        message: "Historial parqueo no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const historialParqueoUpdated = await historial_parqueo.update(
      id_historial_parqueo,
      {
        id_celda,
        id_vehiculo,
        fecha_hora,
      }
    );

    res.status(200).json({
      success: true,
      message: "Historial parqueo actualizado exitosamente",
      data: historialParqueoUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar historial parqueo:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un historial_parqueo
const deleteHistorialParqueo = async (req, res) => {
  try {
    const { id_historial_parqueo } = req.params;

    if (!id_historial_parqueo) {
      return res.status(404).json({
        success: false,
        message: "El historial parqueo no existe",
      });
    }

    // Verificar que el historial_parqueo exista
    const historialParqueo = await historial_parqueo.findById(
      id_historial_parqueo
    );
    if (!historialParqueo) {
      return res.status(404).json({
        success: false,
        message: "Historial parqueo no encontrado",
      });
    }

    await historial_parqueo.delete(id_historial_parqueo);

    res.status(200).json({
      success: true,
      message: "Historial parqueo eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un historial parqueo:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByFechaHora,
  update,
  deleteHistorialParqueo,
};
