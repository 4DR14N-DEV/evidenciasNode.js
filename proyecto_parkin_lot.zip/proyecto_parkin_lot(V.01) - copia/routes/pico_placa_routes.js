// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const pico_placa_controller = require("../controllers/pico_placa_controller");

// rutas CRUD para pico_placa
router.post("/", pico_placa_controller.create); // Crear pico placa
router.get("/", pico_placa_controller.findAll); // Obtener todos los picos placa
router.get("/:id_pico_placa", pico_placa_controller.findById); // Obtener pico placa por id
router.get("/search/:term", pico_placa_controller.searchByTipoVehiculo); // Buscar por tipo_vehiculo
router.put("/:id_pico_placa", pico_placa_controller.update); // Actualizar pico placa
router.delete("/:id_pico_placa", pico_placa_controller.deletePicoPlaca); // Eliminar pico placa

module.exports = router;
