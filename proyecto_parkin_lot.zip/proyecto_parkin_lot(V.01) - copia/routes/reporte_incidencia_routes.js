// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const reporte_incidencia_controller = require("../controllers/reporte_incidencia_controller");

// rutas CRUD para reporte_incidencia
router.post("/", reporte_incidencia_controller.create); // Crear reporte incidencia
router.get("/", reporte_incidencia_controller.findAll); // Obtener todos los reportes incidencia
router.get("/:id_reporte_incidencia", reporte_incidencia_controller.findById); // Obtener reporte incidencia por id
router.get("/search/:term", reporte_incidencia_controller.searchByFechaHora); // Buscar por fecha_hora
router.put("/:id_reporte_incidencia", reporte_incidencia_controller.update); // Actualizar reporte incidencia
router.delete(
  "/:id_reporte_incidencia",
  reporte_incidencia_controller.deleteReporteIncidencia
); // Eliminar reporte incidencia

module.exports = router;
