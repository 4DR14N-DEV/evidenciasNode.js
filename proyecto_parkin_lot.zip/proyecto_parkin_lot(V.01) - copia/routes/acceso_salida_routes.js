// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const acceso_salida_controller = require("../controllers/acceso_salida_controller");

// rutas CRUD para acceso_salida
router.post("/", acceso_salida_controller.create); // Crear acceso salida
router.get("/", acceso_salida_controller.findAll); // Obtener todos los accesos salida
router.get("/:id_acceso_salida", acceso_salida_controller.findById); // Obtener acceso salida por id
router.get("/search/:term", acceso_salida_controller.searchByMovimiento); // Buscar por movimiento
router.put("/:id_acceso_salida", acceso_salida_controller.update); // Actualizar acceso salida
router.delete(
  "/:id_acceso_salida",
  acceso_salida_controller.deleteAccesoSalida
); // Eliminar acceso salida

module.exports = router;
