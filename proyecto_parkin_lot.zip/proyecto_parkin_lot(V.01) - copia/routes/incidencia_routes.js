// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const incidencia_controller = require("../controllers/incidencia_controller");

// rutas CRUD para incidencia
router.post("/", incidencia_controller.create); // Crear incidencia
router.get("/", incidencia_controller.findAll); // Obtener todos los incidencias
router.get("/:id_incidencia", incidencia_controller.findById); // Obtener incidencia por id
router.get("/search/:term", incidencia_controller.searchByNombre); // Buscar por nombre
router.put("/:id_incidencia", incidencia_controller.update); // Actualizar incidencia
router.delete("/:id_incidencia", incidencia_controller.deleteIncidencia); // Eliminar incidencia

module.exports = router;
