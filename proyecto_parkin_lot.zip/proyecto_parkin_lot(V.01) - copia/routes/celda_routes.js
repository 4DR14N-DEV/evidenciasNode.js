// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const celda_controller = require("../controllers/celda_controller");

// rutas CRUD para celda
router.post("/", celda_controller.create); // Crear celda
router.get("/", celda_controller.findAll); // Obtener todos los celdas
router.get("/:id_celda", celda_controller.findById); // Obtener celda por id
router.get("/search/:term", celda_controller.searchByTipo); // Buscar por tipo
router.put("/:id_celda", celda_controller.update); // Actualizar celda
router.delete("/:id_celda", celda_controller.deleteCelda); // Eliminar celda

module.exports = router;
