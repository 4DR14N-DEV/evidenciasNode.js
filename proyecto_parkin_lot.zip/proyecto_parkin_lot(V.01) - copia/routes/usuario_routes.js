// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const usuario_controller = require("../controllers/usuario_controller");

// rutas CRUD para usuario
router.post("/", usuario_controller.create); // Crear usuario
router.get("/", usuario_controller.findAll); // Obtener todos los usuarios
router.get("/:id_usuario", usuario_controller.findById); // Obtener usuario por id
router.get("/search/:term", usuario_controller.searchByPrimerNombre); // Buscar por primer_nombre
router.put("/:id_usuario", usuario_controller.update); // Actualizar usuario
router.delete("/:id_usuario", usuario_controller.deleteUsuario); // Eliminar usuario
router.post("/authenticate", usuario_controller.authenticate); // Autenticar usuario (login)

module.exports = router;
