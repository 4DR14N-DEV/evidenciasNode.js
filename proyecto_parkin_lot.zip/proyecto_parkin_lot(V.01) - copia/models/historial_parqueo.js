const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para historial_parqueo
const historialParqueoEsquema = new mongoose.Schema(
  {
    id_historial_parqueo: { type: Number, unique: true },
    id_celda: { type: Number, ref: "celda", required: true },
    id_vehiculo: { type: Number, ref: "vehiculo", required: true },
    fecha_hora: { type: String, required: true },
  },
  {
    timestamps: true,
    collection: "historial_parqueo", // Forza el nombre 'historial_parqueo'
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtuales para populate
historialParqueoEsquema.virtual("celda", {
  ref: "celda",
  localField: "id_celda",
  foreignField: "id_celda",
  justOne: true,
});

historialParqueoEsquema.virtual("vehiculo", {
  ref: "vehiculo",
  localField: "id_vehiculo",
  foreignField: "id_vehiculo",
  justOne: true,
});

// Metodo para guardar un historial_parqueo

historialParqueoEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_historial_parqueo",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_historial_parqueo = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un historial_parqueo
historialParqueoEsquema.statics.create = async function (data) {
  try {
    const historial_parqueo = new this(data);
    await historial_parqueo.save();
    return {
      id_historial_parqueo: historial_parqueo.id_historial_parqueo,
      id_celda: historial_parqueo.id_celda,
      id_vehiculo: historial_parqueo.id_vehiculo,
      fecha_hora: historial_parqueo.fecha_hora,
    };
  } catch (error) {
    throw new Error(`Error al crear historial_parqueo: ${error.message}`);
  }
};

// Consultar todos los historial_parqueo
historialParqueoEsquema.statics.findAll = async function () {
  try {
    const historial_parqueos = await this.find().sort({ fecha_hora: 1 });
    return historial_parqueos.map((historial_parqueo) => ({
      id_historial_parqueo: historial_parqueo.id_historial_parqueo,
      id_celda: historial_parqueo.id_celda,
      id_vehiculo: historial_parqueo.id_vehiculo,
      fecha_hora: historial_parqueo.fecha_hora,
    }));
  } catch (error) {
    throw new Error(`Error al obtener historial_parqueo: ${error.message}`);
  }
};

// buscar por id
historialParqueoEsquema.statics.findById = async function (
  id_historial_parqueo
) {
  try {
    const historial_parqueo = await this.findOne({ id_historial_parqueo });
    if (!historial_parqueo) return null;
    return {
      id_historial_parqueo: historial_parqueo.id_historial_parqueo,
      id_celda: historial_parqueo.id_celda,
      id_vehiculo: historial_parqueo.id_vehiculo,
      fecha_hora: historial_parqueo.fecha_hora,
    };
  } catch (error) {
    throw new Error(`Error al obtener el historial_parqueo: ${error.message}`);
  }
};

// Buscar por fecha_hora
historialParqueoEsquema.statics.searchByFechaHora = async function (
  searchterm
) {
  try {
    const historial_parqueos = await this.find({
      fecha_hora: { $regex: searchterm, $options: "i" },
    }).sort({ fecha_hora: 1 });
    return historial_parqueos.map((historial_parqueo) => ({
      id_historial_parqueo: historial_parqueo.id_historial_parqueo,
      id_celda: historial_parqueo.id_celda,
      id_vehiculo: historial_parqueo.id_vehiculo,
      fecha_hora: historial_parqueo.fecha_hora,
    }));
  } catch (error) {
    throw new Error(`Error al obtener historial_parqueo: ${error.message}`);
  }
};

// Actualizar historial_parqueo
historialParqueoEsquema.statics.update = async function (
  id_historial_parqueo,
  data
) {
  try {
    const historial_parqueo = await this.findOneAndUpdate(
      { id_historial_parqueo },
      data,
      { new: true, runValidators: true }
    );
    if (!historial_parqueo) {
      throw new Error("Historial_parqueo no encontrado");
    }
    return {
      id_historial_parqueo: historial_parqueo.id_historial_parqueo,
      id_celda: historial_parqueo.id_celda,
      id_vehiculo: historial_parqueo.id_vehiculo,
      fecha_hora: historial_parqueo.fecha_hora,
    };
  } catch (error) {
    throw new Error(
      `Error al actualizar el historial_parqueo: ${error.message}`
    );
  }
};

// Eliminar un historial_parqueo
historialParqueoEsquema.statics.delete = async function (id_historial_parqueo) {
  try {
    const result = await this.findOneAndDelete({ id_historial_parqueo });

    if (!result) {
      throw new Error("Historial_parqueo no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el historial_parqueo: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const historial_parqueo = mongoose.model(
  "historial_parqueo",
  historialParqueoEsquema
);
module.exports = historial_parqueo;
