const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para reporte_incidencia
const reporteIncidenciaEsquema = new mongoose.Schema(
  {
    id_reporte_incidencia: { type: Number, unique: true },
    id_vehiculo: { type: Number, ref: "vehiculo", required: true },
    id_incidencia: { type: Number, ref: "incidencia", required: true },
    fecha_hora: { type: String, required: true },
  },
  {
    timestamps: true,
    collection: "reporte_incidencia", // Forza el nombre 'reporte_incidencia'
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtuales para populate
reporteIncidenciaEsquema.virtual("vehiculo", {
  ref: "vehiculo",
  localField: "id_vehiculo",
  foreignField: "id_vehiculo",
  justOne: true,
});

reporteIncidenciaEsquema.virtual("incidencia", {
  ref: "incidencia",
  localField: "id_incidencia",
  foreignField: "id_incidencia",
  justOne: true,
});

// Metodo para guardar un reporte_incidencia

reporteIncidenciaEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_reporte_incidencia",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_reporte_incidencia = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un reporte_incidencia
reporteIncidenciaEsquema.statics.create = async function (data) {
  try {
    const reporte_incidencia = new this(data);
    await reporte_incidencia.save();
    return {
      id_reporte_incidencia: reporte_incidencia.id_reporte_incidencia,
      id_vehiculo: reporte_incidencia.id_vehiculo,
      id_incidencia: reporte_incidencia.id_incidencia,
      fecha_hora: reporte_incidencia.fecha_hora,
    };
  } catch (error) {
    throw new Error(`Error al crear reporte_incidencia: ${error.message}`);
  }
};

// Consultar todos los reporte_incidencia
reporteIncidenciaEsquema.statics.findAll = async function () {
  try {
    const reporte_incidencias = await this.find().sort({ fecha_hora: 1 });
    return reporte_incidencias.map((reporte_incidencia) => ({
      id_reporte_incidencia: reporte_incidencia.id_reporte_incidencia,
      id_vehiculo: reporte_incidencia.id_vehiculo,
      id_incidencia: reporte_incidencia.id_incidencia,
      fecha_hora: reporte_incidencia.fecha_hora,
    }));
  } catch (error) {
    throw new Error(`Error al obtener reporte_incidencia: ${error.message}`);
  }
};

// buscar por id
reporteIncidenciaEsquema.statics.findById = async function (
  id_reporte_incidencia
) {
  try {
    const reporte_incidencia = await this.findOne({ id_reporte_incidencia });
    if (!reporte_incidencia) return null;
    return {
      id_reporte_incidencia: reporte_incidencia.id_reporte_incidencia,
      id_vehiculo: reporte_incidencia.id_vehiculo,
      id_incidencia: reporte_incidencia.id_incidencia,
      fecha_hora: reporte_incidencia.fecha_hora,
    };
  } catch (error) {
    throw new Error(`Error al obtener el reporte_incidencia: ${error.message}`);
  }
};

// Buscar por fecha_hora
reporteIncidenciaEsquema.statics.searchByFechaHora = async function (
  searchterm
) {
  try {
    const reporte_incidencias = await this.find({
      fecha_hora: { $regex: searchterm, $options: "i" },
    }).sort({ fecha_hora: 1 });
    return reporte_incidencias.map((reporte_incidencia) => ({
      id_reporte_incidencia: reporte_incidencia.id_reporte_incidencia,
      id_vehiculo: reporte_incidencia.id_vehiculo,
      id_incidencia: reporte_incidencia.id_incidencia,
      fecha_hora: reporte_incidencia.fecha_hora,
    }));
  } catch (error) {
    throw new Error(`Error al obtener reporte_incidencia: ${error.message}`);
  }
};

// Actualizar reporte_incidencia
reporteIncidenciaEsquema.statics.update = async function (
  id_reporte_incidencia,
  data
) {
  try {
    const reporte_incidencia = await this.findOneAndUpdate(
      { id_reporte_incidencia },
      data,
      { new: true, runValidators: true }
    );
    if (!reporte_incidencia) {
      throw new Error("Reporte_incidencia no encontrado");
    }
    return {
      id_reporte_incidencia: reporte_incidencia.id_reporte_incidencia,
      id_vehiculo: reporte_incidencia.id_vehiculo,
      id_incidencia: reporte_incidencia.id_incidencia,
      fecha_hora: reporte_incidencia.fecha_hora,
    };
  } catch (error) {
    throw new Error(
      `Error al actualizar el reporte_incidencia: ${error.message}`
    );
  }
};

// Eliminar un reporte_incidencia
reporteIncidenciaEsquema.statics.delete = async function (
  id_reporte_incidencia
) {
  try {
    const result = await this.findOneAndDelete({ id_reporte_incidencia });

    if (!result) {
      throw new Error("Reporte_incidencia no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(
      `Error al eliminar el reporte_incidencia: ${error.message}`
    );
  }
};

// Exportar el modelo/esquema
const reporte_incidencia = mongoose.model(
  "reporte_incidencia",
  reporteIncidenciaEsquema
);
module.exports = reporte_incidencia;
