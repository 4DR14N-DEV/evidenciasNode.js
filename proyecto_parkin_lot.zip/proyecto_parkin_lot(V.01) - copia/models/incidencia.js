const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para incidencia
const incidenciaEsquema = new mongoose.Schema(
  {
    id_incidencia: { type: Number, unique: true },
    nombre: { type: String, required: true },
  },
  {
    timestamps: true,
    collection: "incidencia", // Forza el nombre 'incidencia'
  }
);

// Metodo para guardar un incidencia

incidenciaEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_incidencia",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_incidencia = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un incidencia
incidenciaEsquema.statics.create = async function (data) {
  try {
    const incidencia = new this(data);
    await incidencia.save();
    return {
      id_incidencia: incidencia.id_incidencia,
      nombre: incidencia.nombre,
    };
  } catch (error) {
    throw new Error(`Error al crear incidencia: ${error.message}`);
  }
};

// Consultar todos los incidencia
incidenciaEsquema.statics.findAll = async function () {
  try {
    const incidencias = await this.find().sort({ nombre: 1 });
    return incidencias.map((incidencia) => ({
      id_incidencia: incidencia.id_incidencia,
      nombre: incidencia.nombre,
    }));
  } catch (error) {
    throw new Error(`Error al obtener incidencia: ${error.message}`);
  }
};

// buscar por id
incidenciaEsquema.statics.findById = async function (id_incidencia) {
  try {
    const incidencia = await this.findOne({ id_incidencia });
    if (!incidencia) return null;
    return {
      id_incidencia: incidencia.id_incidencia,
      nombre: incidencia.nombre,
    };
  } catch (error) {
    throw new Error(`Error al obtener el incidencia: ${error.message}`);
  }
};

// Buscar por nombre
incidenciaEsquema.statics.searchByNombre = async function (searchterm) {
  try {
    const incidencias = await this.find({
      nombre: { $regex: searchterm, $options: "i" },
    }).sort({ nombre: 1 });
    return incidencias.map((incidencia) => ({
      id_incidencia: incidencia.id_incidencia,
      nombre: incidencia.nombre,
    }));
  } catch (error) {
    throw new Error(`Error al obtener incidencia: ${error.message}`);
  }
};

// Actualizar incidencia
incidenciaEsquema.statics.update = async function (id_incidencia, data) {
  try {
    const incidencia = await this.findOneAndUpdate({ id_incidencia }, data, {
      new: true,
      runValidators: true,
    });
    if (!incidencia) {
      throw new Error("Incidencia no encontrado");
    }
    return {
      id_incidencia: incidencia.id_incidencia,
      nombre: incidencia.nombre,
    };
  } catch (error) {
    throw new Error(`Error al actualizar el incidencia: ${error.message}`);
  }
};

// Eliminar un incidencia
incidenciaEsquema.statics.delete = async function (id_incidencia) {
  try {
    // Verificar si hay reporte_incidencia que usan esta incidencia
    const reporteIncidencia = mongoose.model("reporte_incidencia");
    const reporteCount = await reporteIncidencia.countDocuments({
      id_incidencia: id_incidencia,
    });

    if (reporteCount > 0) {
      throw new Error(
        "No se puede Eliminar la incidencia porque tiene reportes de incidencia asociados"
      );
    }

    const result = await this.findOneAndDelete({ id_incidencia });

    if (!result) {
      throw new Error("Incidencia no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el incidencia: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const incidencia = mongoose.model("incidencia", incidenciaEsquema);
module.exports = incidencia;
