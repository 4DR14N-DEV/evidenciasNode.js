const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para tipo usuario
const perfilUsuarioEsquema = new mongoose.Schema(
  {
    id_perfil_usuario: { type: Number, unique: true },
    perfil: { type: String, required: true },
  },
  {
    timestamps: true,
    collection: "perfil_usuario", // Forza el nombre 'perfil_usuario'
  }
);

// Metodo para guardar un perfil de usuario

perfilUsuarioEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_perfil_usuario",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_perfil_usuario = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un perfil de usuario
perfilUsuarioEsquema.statics.create = async function (data) {
  try {
    const perfil_usuario = new this(data);
    await perfil_usuario.save();
    return {
      id_perfil_usuario: perfil_usuario.id_perfil_usuario,
      perfil: perfil_usuario.perfil,
    };
  } catch (error) {
    throw new Error(`Error al crear perfil de usuario: ${error.message}`);
  }
};

// Consultar todos los perfiles de usuario
perfilUsuarioEsquema.statics.findAll = async function () {
  try {
    const perfiles = await this.find().sort({ perfil: 1 });
    return perfiles.map((profile) => ({
      id_perfil_usuario: profile.id_perfil_usuario,
      perfil: profile.perfil,
    }));
  } catch (error) {
    throw new Error(`Error al obtener perfiles de usuario: ${error.message}`);
  }
};

// buscar por id
perfilUsuarioEsquema.statics.findById = async function (id_perfil_usuario) {
  try {
    const profile = await this.findOne({ id_perfil_usuario });
    if (!profile) return null;
    return {
      id_perfil_usuario: profile.id_perfil_usuario,
      perfil: profile.perfil,
    };
  } catch (error) {
    throw new Error(`Error al obtener el perfil de usuario: ${error.message}`);
  }
};

// Buscar por perfil
perfilUsuarioEsquema.statics.searchByProfile = async function (searchterm) {
  try {
    const profiles = await this.find({
      perfil: { $regex: searchterm, $options: "i" },
    }).sort({ perfil: 1 });
    return profiles.map((profile) => ({
      id_perfil_usuario: profile.id_perfil_usuario,
      perfil: profile.perfil,
    }));
  } catch (error) {
    throw new Error(`Error al obtener perfil de usuario: ${error.message}`);
  }
};

// Actualizar perfil de usuario
perfilUsuarioEsquema.statics.update = async function (id_perfil_usuario, data) {
  try {
    const perfil_usuario = await this.findOneAndUpdate(
      { id_perfil_usuario },
      data,
      { new: true, runValidators: true }
    );
    if (!perfil_usuario) {
      throw new Error("Perfil de usuario no encontrado");
    }
    return {
      id_perfil_usuario: perfil_usuario.id_perfil_usuario,
      perfil: perfil_usuario.perfil,
    };
  } catch (error) {
    throw new Error(
      `Error al actualizar el perfil de usuario: ${error.message}`
    );
  }
};

// Eliminar un perfil de usuario
perfilUsuarioEsquema.statics.delete = async function (id_perfil_usuario) {
  try {
    // Verificar si hay usuarios que usan ese perfil
    const usuario = mongoose.model("usuario");
    const usuariosCount = await usuario.countDocuments({
      id_perfil_usuario: id_perfil_usuario,
    });

    if (usuariosCount > 0) {
      throw new Error(
        "No se puede Eliminar el perfil de usuario porque tiene usuarios asociados"
      );
    }

    const result = await this.findOneAndDelete({ id_perfil_usuario });

    if (!result) {
      throw new Error("Perfil de usuario no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el perfil de usuario: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const perfil_usuario = mongoose.model("perfil_usuario", perfilUsuarioEsquema);
module.exports = perfil_usuario;
