const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para celda
const celdaEsquema = new mongoose.Schema(
  {
    id_celda: { type: Number, unique: true },
    tipo: { type: String, required: true },
    estado: { type: String, required: true },
  },
  {
    timestamps: true,
    collection: "celda", // Forza el nombre 'celda'
  }
);

// Metodo para guardar un celda

celdaEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_celda",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_celda = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un celda
celdaEsquema.statics.create = async function (data) {
  try {
    const celda = new this(data);
    await celda.save();
    return {
      id_celda: celda.id_celda,
      tipo: celda.tipo,
      estado: celda.estado,
    };
  } catch (error) {
    throw new Error(`Error al crear celda: ${error.message}`);
  }
};

// Consultar todos los celda
celdaEsquema.statics.findAll = async function () {
  try {
    const celdas = await this.find().sort({ tipo: 1 });
    return celdas.map((celda) => ({
      id_celda: celda.id_celda,
      tipo: celda.tipo,
      estado: celda.estado,
    }));
  } catch (error) {
    throw new Error(`Error al obtener celda: ${error.message}`);
  }
};

// buscar por id
celdaEsquema.statics.findById = async function (id_celda) {
  try {
    const celda = await this.findOne({ id_celda });
    if (!celda) return null;
    return {
      id_celda: celda.id_celda,
      tipo: celda.tipo,
      estado: celda.estado,
    };
  } catch (error) {
    throw new Error(`Error al obtener el celda: ${error.message}`);
  }
};

// Buscar por tipo
celdaEsquema.statics.searchByTipo = async function (searchterm) {
  try {
    const celdas = await this.find({
      tipo: { $regex: searchterm, $options: "i" },
    }).sort({ tipo: 1 });
    return celdas.map((celda) => ({
      id_celda: celda.id_celda,
      tipo: celda.tipo,
      estado: celda.estado,
    }));
  } catch (error) {
    throw new Error(`Error al obtener celda: ${error.message}`);
  }
};

// Actualizar celda
celdaEsquema.statics.update = async function (id_celda, data) {
  try {
    const celda = await this.findOneAndUpdate({ id_celda }, data, {
      new: true,
      runValidators: true,
    });
    if (!celda) {
      throw new Error("Celda no encontrado");
    }
    return {
      id_celda: celda.id_celda,
      tipo: celda.tipo,
      estado: celda.estado,
    };
  } catch (error) {
    throw new Error(`Error al actualizar el celda: ${error.message}`);
  }
};

// Eliminar un celda
celdaEsquema.statics.delete = async function (id_celda) {
  try {
    // Verificar si hay historial_parqueo que usan esta celda
    const historialParqueo = mongoose.model("historial_parqueo");
    const historialCount = await historialParqueo.countDocuments({
      id_celda: id_celda,
    });

    if (historialCount > 0) {
      throw new Error(
        "No se puede Eliminar la celda porque tiene historial de parqueo asociados"
      );
    }

    const result = await this.findOneAndDelete({ id_celda });

    if (!result) {
      throw new Error("Celda no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el celda: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const celda = mongoose.model("celda", celdaEsquema);
module.exports = celda;
