const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para usuario
const usuarioEsquema = new mongoose.Schema(
  {
    id_usuario: { type: Number, unique: true },
    tipo_documento: { type: String, required: true },
    numero_documento: { type: Number, required: true },
    primer_nombre: { type: String, required: true },
    segundo_nombre: { type: String },
    primer_apellido: { type: String, required: true },
    segundo_apellido: { type: String },
    correo: { type: String, required: true },
    numero_celular: { type: Number },
    foto_perfil: { type: String },
    estado: { type: String, required: true },
    clave: { type: String, required: true },
    id_perfil_usuario: { type: Number, required: true },
  },
  {
    timestamps: true,
    collection: "usuario", // Forza el nombre 'usuario'
  }
);

// Metodo para guardar un usuario

usuarioEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_usuario",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_usuario = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un usuario
usuarioEsquema.statics.create = async function (data) {
  try {
    const usuario = new this(data);
    await usuario.save();
    return {
      id_usuario: usuario.id_usuario,
      tipo_documento: usuario.tipo_documento,
      numero_documento: usuario.numero_documento,
      primer_nombre: usuario.primer_nombre,
      segundo_nombre: usuario.segundo_nombre,
      primer_apellido: usuario.primer_apellido,
      segundo_apellido: usuario.segundo_apellido,
      correo: usuario.correo,
      numero_celular: usuario.numero_celular,
      foto_perfil: usuario.foto_perfil,
      estado: usuario.estado,
      clave: usuario.clave,
      id_perfil_usuario: usuario.id_perfil_usuario,
    };
  } catch (error) {
    throw new Error(`Error al crear usuario: ${error.message}`);
  }
};

// Consultar todos los usuario
usuarioEsquema.statics.findAll = async function () {
  try {
    const usuarios = await this.find().sort({ primer_nombre: 1 });
    return usuarios.map((usuario) => ({
      id_usuario: usuario.id_usuario,
      tipo_documento: usuario.tipo_documento,
      numero_documento: usuario.numero_documento,
      primer_nombre: usuario.primer_nombre,
      segundo_nombre: usuario.segundo_nombre,
      primer_apellido: usuario.primer_apellido,
      segundo_apellido: usuario.segundo_apellido,
      correo: usuario.correo,
      numero_celular: usuario.numero_celular,
      foto_perfil: usuario.foto_perfil,
      estado: usuario.estado,
      clave: usuario.clave,
      id_perfil_usuario: usuario.id_perfil_usuario,
    }));
  } catch (error) {
    throw new Error(`Error al obtener usuario: ${error.message}`);
  }
};

// buscar por id
usuarioEsquema.statics.findById = async function (id_usuario) {
  try {
    const usuario = await this.findOne({ id_usuario });
    if (!usuario) return null;
    return {
      id_usuario: usuario.id_usuario,
      tipo_documento: usuario.tipo_documento,
      numero_documento: usuario.numero_documento,
      primer_nombre: usuario.primer_nombre,
      segundo_nombre: usuario.segundo_nombre,
      primer_apellido: usuario.primer_apellido,
      segundo_apellido: usuario.segundo_apellido,
      correo: usuario.correo,
      numero_celular: usuario.numero_celular,
      foto_perfil: usuario.foto_perfil,
      estado: usuario.estado,
      clave: usuario.clave,
      id_perfil_usuario: usuario.id_perfil_usuario,
    };
  } catch (error) {
    throw new Error(`Error al obtener el usuario: ${error.message}`);
  }
};

// Buscar por primer_nombre
usuarioEsquema.statics.searchByPrimerNombre = async function (searchterm) {
  try {
    const usuarios = await this.find({
      primer_nombre: { $regex: searchterm, $options: "i" },
    }).sort({ primer_nombre: 1 });
    return usuarios.map((usuario) => ({
      id_usuario: usuario.id_usuario,
      tipo_documento: usuario.tipo_documento,
      numero_documento: usuario.numero_documento,
      primer_nombre: usuario.primer_nombre,
      segundo_nombre: usuario.segundo_nombre,
      primer_apellido: usuario.primer_apellido,
      segundo_apellido: usuario.segundo_apellido,
      correo: usuario.correo,
      numero_celular: usuario.numero_celular,
      foto_perfil: usuario.foto_perfil,
      estado: usuario.estado,
      clave: usuario.clave,
      id_perfil_usuario: usuario.id_perfil_usuario,
    }));
  } catch (error) {
    throw new Error(`Error al obtener usuario: ${error.message}`);
  }
};

// Actualizar usuario
usuarioEsquema.statics.update = async function (id_usuario, data) {
  try {
    const usuario = await this.findOneAndUpdate({ id_usuario }, data, {
      new: true,
      runValidators: true,
    });
    if (!usuario) {
      throw new Error("Usuario no encontrado");
    }
    return {
      id_usuario: usuario.id_usuario,
      tipo_documento: usuario.tipo_documento,
      numero_documento: usuario.numero_documento,
      primer_nombre: usuario.primer_nombre,
      segundo_nombre: usuario.segundo_nombre,
      primer_apellido: usuario.primer_apellido,
      segundo_apellido: usuario.segundo_apellido,
      correo: usuario.correo,
      numero_celular: usuario.numero_celular,
      foto_perfil: usuario.foto_perfil,
      estado: usuario.estado,
      clave: usuario.clave,
      id_perfil_usuario: usuario.id_perfil_usuario,
    };
  } catch (error) {
    throw new Error(`Error al actualizar el usuario: ${error.message}`);
  }
};

// Eliminar un usuario
usuarioEsquema.statics.delete = async function (id_usuario) {
  try {
    // Verificar si hay vehiculo que usan este usuario
    const vehiculo = mongoose.model("vehiculo");
    const vehiculoCount = await vehiculo.countDocuments({
      id_usuario: id_usuario,
    });

    if (vehiculoCount > 0) {
      throw new Error(
        "No se puede Eliminar el usuario porque tiene vehiculos asociados"
      );
    }

    const result = await this.findOneAndDelete({ id_usuario });

    if (!result) {
      throw new Error("Usuario no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el usuario: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const usuario = mongoose.model("usuario", usuarioEsquema);
module.exports = usuario;
