const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para acceso_salida
const accesoSalidaEsquema = new mongoose.Schema(
  {
    id_acceso_salida: { type: Number, unique: true },
    movimiento: { type: String, required: true },
    fecha_hora: { type: String, required: true },
    puerta: { type: String, required: true },
    tiempo_estadia: { type: String, required: true },
    id_vehiculo: { type: Number, required: true },
  },
  {
    timestamps: true,
    collection: "acceso_salida", // Forza el nombre 'acceso_salida'
  }
);

// Metodo para guardar un acceso_salida

accesoSalidaEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_acceso_salida",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_acceso_salida = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un acceso_salida
accesoSalidaEsquema.statics.create = async function (data) {
  try {
    const acceso_salida = new this(data);
    await acceso_salida.save();
    return {
      id_acceso_salida: acceso_salida.id_acceso_salida,
      movimiento: acceso_salida.movimiento,
      fecha_hora: acceso_salida.fecha_hora,
      puerta: acceso_salida.puerta,
      tiempo_estadia: acceso_salida.tiempo_estadia,
      id_vehiculo: acceso_salida.id_vehiculo,
    };
  } catch (error) {
    throw new Error(`Error al crear acceso_salida: ${error.message}`);
  }
};

// Consultar todos los acceso_salida
accesoSalidaEsquema.statics.findAll = async function () {
  try {
    const acceso_salidas = await this.find().sort({ movimiento: 1 });
    return acceso_salidas.map((acceso_salida) => ({
      id_acceso_salida: acceso_salida.id_acceso_salida,
      movimiento: acceso_salida.movimiento,
      fecha_hora: acceso_salida.fecha_hora,
      puerta: acceso_salida.puerta,
      tiempo_estadia: acceso_salida.tiempo_estadia,
      id_vehiculo: acceso_salida.id_vehiculo,
    }));
  } catch (error) {
    throw new Error(`Error al obtener acceso_salida: ${error.message}`);
  }
};

// buscar por id
accesoSalidaEsquema.statics.findById = async function (id_acceso_salida) {
  try {
    const acceso_salida = await this.findOne({ id_acceso_salida });
    if (!acceso_salida) return null;
    return {
      id_acceso_salida: acceso_salida.id_acceso_salida,
      movimiento: acceso_salida.movimiento,
      fecha_hora: acceso_salida.fecha_hora,
      puerta: acceso_salida.puerta,
      tiempo_estadia: acceso_salida.tiempo_estadia,
      id_vehiculo: acceso_salida.id_vehiculo,
    };
  } catch (error) {
    throw new Error(`Error al obtener el acceso_salida: ${error.message}`);
  }
};

// Buscar por movimiento
accesoSalidaEsquema.statics.searchByMovimiento = async function (searchterm) {
  try {
    const acceso_salidas = await this.find({
      movimiento: { $regex: searchterm, $options: "i" },
    }).sort({ movimiento: 1 });
    return acceso_salidas.map((acceso_salida) => ({
      id_acceso_salida: acceso_salida.id_acceso_salida,
      movimiento: acceso_salida.movimiento,
      fecha_hora: acceso_salida.fecha_hora,
      puerta: acceso_salida.puerta,
      tiempo_estadia: acceso_salida.tiempo_estadia,
      id_vehiculo: acceso_salida.id_vehiculo,
    }));
  } catch (error) {
    throw new Error(`Error al obtener acceso_salida: ${error.message}`);
  }
};

// Actualizar acceso_salida
accesoSalidaEsquema.statics.update = async function (id_acceso_salida, data) {
  try {
    const acceso_salida = await this.findOneAndUpdate(
      { id_acceso_salida },
      data,
      { new: true, runValidators: true }
    );
    if (!acceso_salida) {
      throw new Error("Acceso_salida no encontrado");
    }
    return {
      id_acceso_salida: acceso_salida.id_acceso_salida,
      movimiento: acceso_salida.movimiento,
      fecha_hora: acceso_salida.fecha_hora,
      puerta: acceso_salida.puerta,
      tiempo_estadia: acceso_salida.tiempo_estadia,
      id_vehiculo: acceso_salida.id_vehiculo,
    };
  } catch (error) {
    throw new Error(`Error al actualizar el acceso_salida: ${error.message}`);
  }
};

// Eliminar un acceso_salida
accesoSalidaEsquema.statics.delete = async function (id_acceso_salida) {
  try {
    const result = await this.findOneAndDelete({ id_acceso_salida });

    if (!result) {
      throw new Error("Acceso_salida no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el acceso_salida: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const acceso_salida = mongoose.model("acceso_salida", accesoSalidaEsquema);
module.exports = acceso_salida;
