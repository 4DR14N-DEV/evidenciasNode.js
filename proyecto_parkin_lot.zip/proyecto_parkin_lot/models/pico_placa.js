const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para pico_placa
const picoPlacaEsquema = new mongoose.Schema(
  {
    id_pico_placa: { type: Number, unique: true },
    tipo_vehiculo: { type: String, required: true },
    numero: { type: Number, required: true },
    dia: { type: String, required: true },
  },
  {
    timestamps: true,
    collection: "pico_placa", // Forza el nombre 'pico_placa'
  }
);

// Metodo para guardar un pico_placa

picoPlacaEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_pico_placa",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_pico_placa = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un pico_placa
picoPlacaEsquema.statics.create = async function (data) {
  try {
    const pico_placa = new this(data);
    await pico_placa.save();
    return {
      id_pico_placa: pico_placa.id_pico_placa,
      tipo_vehiculo: pico_placa.tipo_vehiculo,
      numero: pico_placa.numero,
      dia: pico_placa.dia,
    };
  } catch (error) {
    throw new Error(`Error al crear pico_placa: ${error.message}`);
  }
};

// Consultar todos los pico_placa
picoPlacaEsquema.statics.findAll = async function () {
  try {
    const pico_placas = await this.find().sort({ tipo_vehiculo: 1 });
    return pico_placas.map((pico_placa) => ({
      id_pico_placa: pico_placa.id_pico_placa,
      tipo_vehiculo: pico_placa.tipo_vehiculo,
      numero: pico_placa.numero,
      dia: pico_placa.dia,
    }));
  } catch (error) {
    throw new Error(`Error al obtener pico_placa: ${error.message}`);
  }
};

// buscar por id
picoPlacaEsquema.statics.findById = async function (id_pico_placa) {
  try {
    const pico_placa = await this.findOne({ id_pico_placa });
    if (!pico_placa) return null;
    return {
      id_pico_placa: pico_placa.id_pico_placa,
      tipo_vehiculo: pico_placa.tipo_vehiculo,
      numero: pico_placa.numero,
      dia: pico_placa.dia,
    };
  } catch (error) {
    throw new Error(`Error al obtener el pico_placa: ${error.message}`);
  }
};

// Buscar por tipo_vehiculo
picoPlacaEsquema.statics.searchByTipoVehiculo = async function (searchterm) {
  try {
    const pico_placas = await this.find({
      tipo_vehiculo: { $regex: searchterm, $options: "i" },
    }).sort({ tipo_vehiculo: 1 });
    return pico_placas.map((pico_placa) => ({
      id_pico_placa: pico_placa.id_pico_placa,
      tipo_vehiculo: pico_placa.tipo_vehiculo,
      numero: pico_placa.numero,
      dia: pico_placa.dia,
    }));
  } catch (error) {
    throw new Error(`Error al obtener pico_placa: ${error.message}`);
  }
};

// Actualizar pico_placa
picoPlacaEsquema.statics.update = async function (id_pico_placa, data) {
  try {
    const pico_placa = await this.findOneAndUpdate({ id_pico_placa }, data, {
      new: true,
      runValidators: true,
    });
    if (!pico_placa) {
      throw new Error("Pico_placa no encontrado");
    }
    return {
      id_pico_placa: pico_placa.id_pico_placa,
      tipo_vehiculo: pico_placa.tipo_vehiculo,
      numero: pico_placa.numero,
      dia: pico_placa.dia,
    };
  } catch (error) {
    throw new Error(`Error al actualizar el pico_placa: ${error.message}`);
  }
};

// Eliminar un pico_placa
picoPlacaEsquema.statics.delete = async function (id_pico_placa) {
  try {
    const result = await this.findOneAndDelete({ id_pico_placa });

    if (!result) {
      throw new Error("Pico_placa no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el pico_placa: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const pico_placa = mongoose.model("pico_placa", picoPlacaEsquema);
module.exports = pico_placa;
