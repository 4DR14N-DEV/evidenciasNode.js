const mongoose = require("mongoose"); // requiere la dependencia de mongo

// Crear el esquema para el contador
const contadorEsquema = new mongoose.Schema({
  _id: { type: String, required: true },
  secuencia: { type: Number, default: 0 },
});

// Definir el modelo para el contador
const contador =
  mongoose.models.Counter || mongoose.model("Counter", contadorEsquema);

// Definir el esquema para vehiculo
const vehiculoEsquema = new mongoose.Schema(
  {
    id_vehiculo: { type: Number, unique: true },
    placa: { type: String, required: true },
    color: { type: String, required: true },
    modelo: { type: Number, required: true },
    marca: { type: String, required: true },
    tipo: { type: String, required: true },
    id_usuario: { type: Number, required: true },
  },
  {
    timestamps: true,
    collection: "vehiculo", // Forza el nombre 'vehiculo'
  }
);

// Metodo para guardar un vehiculo

vehiculoEsquema.pre("save", async function (next) {
  if (this.isNew) {
    try {
      const contadorDoc = await contador.findByIdAndUpdate(
        "id_vehiculo",
        { $inc: { secuencia: 1 } },
        { new: true, upsert: true }
      );
      this.id_vehiculo = contadorDoc.secuencia;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Metodo para crear un vehiculo
vehiculoEsquema.statics.create = async function (data) {
  try {
    const vehiculo = new this(data);
    await vehiculo.save();
    return {
      id_vehiculo: vehiculo.id_vehiculo,
      placa: vehiculo.placa,
      color: vehiculo.color,
      modelo: vehiculo.modelo,
      marca: vehiculo.marca,
      tipo: vehiculo.tipo,
      id_usuario: vehiculo.id_usuario,
    };
  } catch (error) {
    throw new Error(`Error al crear vehiculo: ${error.message}`);
  }
};

// Consultar todos los vehiculo
vehiculoEsquema.statics.findAll = async function () {
  try {
    const vehiculos = await this.find().sort({ placa: 1 });
    return vehiculos.map((vehiculo) => ({
      id_vehiculo: vehiculo.id_vehiculo,
      placa: vehiculo.placa,
      color: vehiculo.color,
      modelo: vehiculo.modelo,
      marca: vehiculo.marca,
      tipo: vehiculo.tipo,
      id_usuario: vehiculo.id_usuario,
    }));
  } catch (error) {
    throw new Error(`Error al obtener vehiculo: ${error.message}`);
  }
};

// buscar por id
vehiculoEsquema.statics.findById = async function (id_vehiculo) {
  try {
    const vehiculo = await this.findOne({ id_vehiculo });
    if (!vehiculo) return null;
    return {
      id_vehiculo: vehiculo.id_vehiculo,
      placa: vehiculo.placa,
      color: vehiculo.color,
      modelo: vehiculo.modelo,
      marca: vehiculo.marca,
      tipo: vehiculo.tipo,
      id_usuario: vehiculo.id_usuario,
    };
  } catch (error) {
    throw new Error(`Error al obtener el vehiculo: ${error.message}`);
  }
};

// Buscar por placa
vehiculoEsquema.statics.searchByPlaca = async function (searchterm) {
  try {
    const vehiculos = await this.find({
      placa: { $regex: searchterm, $options: "i" },
    }).sort({ placa: 1 });
    return vehiculos.map((vehiculo) => ({
      id_vehiculo: vehiculo.id_vehiculo,
      placa: vehiculo.placa,
      color: vehiculo.color,
      modelo: vehiculo.modelo,
      marca: vehiculo.marca,
      tipo: vehiculo.tipo,
      id_usuario: vehiculo.id_usuario,
    }));
  } catch (error) {
    throw new Error(`Error al obtener vehiculo: ${error.message}`);
  }
};

// Actualizar vehiculo
vehiculoEsquema.statics.update = async function (id_vehiculo, data) {
  try {
    const vehiculo = await this.findOneAndUpdate({ id_vehiculo }, data, {
      new: true,
      runValidators: true,
    });
    if (!vehiculo) {
      throw new Error("Vehiculo no encontrado");
    }
    return {
      id_vehiculo: vehiculo.id_vehiculo,
      placa: vehiculo.placa,
      color: vehiculo.color,
      modelo: vehiculo.modelo,
      marca: vehiculo.marca,
      tipo: vehiculo.tipo,
      id_usuario: vehiculo.id_usuario,
    };
  } catch (error) {
    throw new Error(`Error al actualizar el vehiculo: ${error.message}`);
  }
};

// Eliminar un vehiculo
vehiculoEsquema.statics.delete = async function (id_vehiculo) {
  try {
    // Verificar si hay acceso_salida que usan este vehiculo
    const accesoSalida = mongoose.model("acceso_salida");
    const accesoCount = await accesoSalida.countDocuments({
      id_vehiculo: id_vehiculo,
    });

    if (accesoCount > 0) {
      throw new Error(
        "No se puede Eliminar el vehiculo porque tiene accesos de salida asociados"
      );
    }

    // Verificar si hay historial_parqueo que usan este vehiculo
    const historialParqueo = mongoose.model("historial_parqueo");
    const historialCount = await historialParqueo.countDocuments({
      id_vehiculo: id_vehiculo,
    });

    if (historialCount > 0) {
      throw new Error(
        "No se puede Eliminar el vehiculo porque tiene historial de parqueo asociados"
      );
    }

    // Verificar si hay reporte_incidencia que usan este vehiculo
    const reporteIncidencia = mongoose.model("reporte_incidencia");
    const reporteCount = await reporteIncidencia.countDocuments({
      id_vehiculo: id_vehiculo,
    });

    if (reporteCount > 0) {
      throw new Error(
        "No se puede Eliminar el vehiculo porque tiene reportes de incidencia asociados"
      );
    }

    const result = await this.findOneAndDelete({ id_vehiculo });

    if (!result) {
      throw new Error("Vehiculo no encontrado");
    }
    return true;
  } catch (error) {
    throw new Error(`Error al eliminar el vehiculo: ${error.message}`);
  }
};

// Exportar el modelo/esquema
const vehiculo = mongoose.model("vehiculo", vehiculoEsquema);
module.exports = vehiculo;
