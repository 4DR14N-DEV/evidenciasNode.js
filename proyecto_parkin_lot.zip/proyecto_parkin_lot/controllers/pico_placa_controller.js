// importar el modulo pico_placa
const pico_placa = require("../models/pico_placa");

// Validar el metodo create/crear pico_placa
const create = async (req, res) => {
  try {
    const { tipo_vehiculo, numero, dia } = req.body;

    if (!tipo_vehiculo || !numero || !dia) {
      return res.status(400).json({
        succes: false,
        message: "Todos los campos requeridos deben ser proporcionados",
      });
    }

    const modelo_pico_placa = await pico_placa.create({
      tipo_vehiculo,
      numero,
      dia,
    }); // Esto Graba en la base de datos

    res.status(201).json({
      succes: true,
      message: "Pico placa registrado exitosamente",
      data: modelo_pico_placa,
    });
  } catch (error) {
    console.error("Error al crear pico_placa: ", error);
    res.status(500).json({
      succes: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los pico_placa
const findAll = async (req, res) => {
  try {
    const picos_placa = await pico_placa.findAll();
    res.status(200).json({
      succes: true,
      message: "Picos placa obtenidos exitosamente",
      data: picos_placa,
    });
  } catch (error) {
    console.error("Error al obtener pico_placa: ", error);
    res.status(500).json({
      succes: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener pico_placa por ID
const findById = async (req, res) => {
  try {
    const { id_pico_placa } = req.params;
    if (!id_pico_placa) {
      return res.status(400).json({
        succes: false,
        message: "El id del pico placa es requerido",
      });
    }

    const picoPlaca = await pico_placa.findById(id_pico_placa);

    if (!picoPlaca) {
      return res.status(404).json({
        succes: false,
        message: "Pico placa no encontrado",
      });
    }

    res.status(200).json({
      succes: true,
      message: "Pico placa obtenido exitosamente",
      data: picoPlaca,
    });
  } catch (error) {
    console.error("Error al obtener pico placa: ", error);
    res.status(500).json({
      succes: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener pico_placa por tipo_vehiculo
const searchByTipoVehiculo = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const picos_placa = await pico_placa.searchByTipoVehiculo(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de picos placa por: "${term}"`,
      data: picos_placa,
    });
  } catch (error) {
    console.error("Error al buscar picos placa: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar pico_placa
const update = async (req, res) => {
  try {
    const { id_pico_placa } = req.params;
    const { tipo_vehiculo, numero, dia } = req.body;

    if (!id_pico_placa) {
      return res.status(404).json({
        success: false,
        message: "El id del pico placa no existe",
      });
    }

    // Verificar que el pico_placa exista
    const picoPlaca = await pico_placa.findById(id_pico_placa);
    if (!picoPlaca) {
      return res.status(404).json({
        success: false,
        message: "Pico placa no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const picoPlacaUpdated = await pico_placa.update(id_pico_placa, {
      tipo_vehiculo,
      numero,
      dia,
    });

    res.status(200).json({
      success: true,
      message: "Pico placa actualizado exitosamente",
      data: picoPlacaUpdated,
    });
  } catch (error) {
    console.error("Error al actualizar pico placa:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un pico_placa
const deletePicoPlaca = async (req, res) => {
  try {
    const { id_pico_placa } = req.params;

    if (!id_pico_placa) {
      return res.status(404).json({
        success: false,
        message: "El pico placa no existe",
      });
    }

    // Verificar que el pico_placa exista
    const picoPlaca = await pico_placa.findById(id_pico_placa);
    if (!picoPlaca) {
      return res.status(404).json({
        success: false,
        message: "Pico placa no encontrado",
      });
    }

    await pico_placa.delete(id_pico_placa);

    res.status(200).json({
      success: true,
      message: "Pico placa eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un pico placa:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByTipoVehiculo,
  update,
  deletePicoPlaca,
};
