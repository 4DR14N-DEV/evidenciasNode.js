// importar el modulo perfil usuario
const perfil_usuario = require("../models/perfil_usuario");

// Validar el metodo create/crear perfil usuario
const create = async (req, res) => {
  try {
    const { perfil } = req.body;

    if (!perfil) {
      return res.status(400).json({
        success: false,
        message: "El perfil es requerido",
      });
    }

    const modelo_perfil_usuario = await perfil_usuario.create({ perfil }); // Esto Graba en la base de datos

    res.status(201).json({
      success: true,
      message: "Perfil de usuario registrado exitosamente",
      data: modelo_perfil_usuario,
    });
  } catch (error) {
    console.error("Error al crear pefil de usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener todos los perfiles de usuario
const findAll = async (req, res) => {
  try {
    const perfiles_usuario = await perfil_usuario.findAll();
    res.status(200).json({
      success: true,
      message: "Perfiles de usuario obtenidos exitosamente",
      data: perfiles_usuario,
    });
  } catch (error) {
    console.error("Error al obtener pefil de usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener perfil de usuario por ID
const findById = async (req, res) => {
  try {
    const { id_perfil_usuario } = req.params;
    if (!id_perfil_usuario) {
      return res.status(400).json({
        success: false,
        message: "El id del perfil de ususario es requerido",
      });
    }

    const perfilUsuario = await perfil_usuario.findById(id_perfil_usuario);

    if (!perfilUsuario) {
      return res.status(404).json({
        success: false,
        message: "Perfil de usuario no econtrado",
      });
    }

    res.status(200).json({
      success: true,
      message: "Perfiles de usuario obtenidos exitosamente",
      data: perfilUsuario,
    });
  } catch (error) {
    console.error("Error al obtener pefiles de usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      data: error.message,
    });
  }
};

// Obtener perfil de usuario por perfil
const searchByProfile = async (req, res) => {
  try {
    const { term } = req.params;

    if (!term) {
      return res.status(400).json({
        success: false,
        message: "El termino de busqueda es requerido",
      });
    }

    const perfiles_usuario = await perfil_usuario.searchByProfile(term);

    res.status(200).json({
      success: true,
      message: `Busqueda de perfiles de usuario por: "${term}"`,
      data: perfiles_usuario,
    });
  } catch (error) {
    console.error("Error al buscar perfiles de usuario: ", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Actualizar perfil de usuario
const update = async (req, res) => {
  try {
    const { id_perfil_usuario } = req.params;
    const { perfil } = req.body;

    if (!id_perfil_usuario) {
      return res.status(404).json({
        success: false,
        message: "El id del perfil de usuario no existe",
      });
    }

    if (!perfil) {
      return res.status(404).json({
        success: false,
        message: "El perfil es requerido",
      });
    }

    // Verificar que el perfil de usuario exista
    const perfilUsuario = await perfil_usuario.findById(id_perfil_usuario);
    if (!perfilUsuario) {
      return res.status(404).json({
        success: false,
        message: "Perfil de usuario no encontrado",
      });
    }

    // Invocar el metodo Update del modelo
    const userProfile = await perfil_usuario.update(id_perfil_usuario, {
      perfil,
    });

    res.status(200).json({
      success: true,
      message: "Perfil de usuario actualizado exitosamente",
      data: userProfile,
    });
  } catch (error) {
    console.error("Error al buscar perfiles de usuario:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Eliminar un perfil de usuario
const deletePerfilUsuario = async (req, res) => {
  try {
    const { id_perfil_usuario } = req.params;

    if (!id_perfil_usuario) {
      return res.status(404).json({
        success: false,
        message: "El perfil de usuario no existe",
      });
    }

    // Verificar que el perfil de usuario exista
    const profileUser = await perfil_usuario.findById(id_perfil_usuario);
    if (!profileUser) {
      return res.status(404).json({
        success: false,
        message: "Perfil de usuario no encontrado",
      });
    }

    await perfil_usuario.delete(id_perfil_usuario);

    res.status(200).json({
      success: true,
      message: "Perfil de usuario eliminado exitosamente",
    });
  } catch (error) {
    console.error("Error al eliminar un perfil de usuario:", error);
    res.status(500).json({
      success: false,
      message: "Error interno del servidor",
      error: error.message,
    });
  }
};

// Exportar los controladores
module.exports = {
  create,
  findAll,
  findById,
  searchByProfile,
  update,
  deletePerfilUsuario,
};
