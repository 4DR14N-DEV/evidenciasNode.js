// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const historial_parqueo_controller = require("../controllers/historial_parqueo_controller");

// rutas CRUD para historial_parqueo
router.post("/", historial_parqueo_controller.create); // Crear historial parqueo
router.get("/", historial_parqueo_controller.findAll); // Obtener todos los historiales parqueo
router.get("/:id_historial_parqueo", historial_parqueo_controller.findById); // Obtener historial parqueo por id
router.get("/search/:term", historial_parqueo_controller.searchByFechaHora); // Buscar por fecha_hora
router.put("/:id_historial_parqueo", historial_parqueo_controller.update); // Actualizar historial parqueo
router.delete(
  "/:id_historial_parqueo",
  historial_parqueo_controller.deleteHistorialParqueo
); // Eliminar historial parqueo

module.exports = router;
