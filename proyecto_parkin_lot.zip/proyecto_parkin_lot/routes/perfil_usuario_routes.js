// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const perfil_usuario_controller = require("../controllers/perfil_usuario_controller");

// rutas CRUD para perfil de usuario
router.post("/", perfil_usuario_controller.create); // Crear perfil de usuario
router.get("/", perfil_usuario_controller.findAll); // Obtener todos los perfiles de usuario
router.get("/:id_perfil_usuario", perfil_usuario_controller.findById); // Obtener perfil de usuario por id
router.get("/search/:term", perfil_usuario_controller.searchByProfile); // Buscar por perfil
router.put("/:id_perfil_usuario", perfil_usuario_controller.update); // Actualizar perfil de usuario
router.delete(
  "/:id_perfil_usuario",
  perfil_usuario_controller.deletePerfilUsuario
); // Eliminar perfil de usuario

module.exports = router; // Exportar las rutas
