// Requiere el framework express
const express = require("express");

// Ocupar el metodo de enrutamiento (Router)
const router = express.Router();

// Acceder a la ruta del controlador
const vehiculo_controller = require("../controllers/vehiculo_controller");

// rutas CRUD para vehiculo
router.post("/", vehiculo_controller.create); // Crear vehiculo
router.get("/", vehiculo_controller.findAll); // Obtener todos los vehiculos
router.get("/:id_vehiculo", vehiculo_controller.findById); // Obtener vehiculo por id
router.get("/search/:term", vehiculo_controller.searchByPlaca); // Buscar por placa
router.put("/:id_vehiculo", vehiculo_controller.update); // Actualizar vehiculo
router.delete("/:id_vehiculo", vehiculo_controller.deleteVehiculo); // Eliminar vehiculo

module.exports = router;
