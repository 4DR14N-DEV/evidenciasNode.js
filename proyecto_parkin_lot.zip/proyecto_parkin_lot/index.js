require("dotenv").config();
const connectDB = require("./config/database");
const perfil_usuario = require("./models/perfil_usuario");
const express = require("express");
const cors = require("cors");

// Importar rutas
const perfil_usuario_routes = require("./routes/perfil_usuario_routes");
const usuario_routes = require("./routes/usuario_routes");
const vehiculo_routes = require("./routes/vehiculo_routes");
const acceso_salida_routes = require("./routes/acceso_salida_routes");
const celda_routes = require("./routes/celda_routes");
const historial_parqueo_routes = require("./routes/historial_parqueo_routes");
const incidencia_routes = require("./routes/incidencia_routes");
const pico_placa_routes = require("./routes/pico_placa_routes");
const reporte_incidencia_routes = require("./routes/reporte_incidencia_routes");

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rutas de la API
app.use("/api/perfil-usuario", perfil_usuario_routes);
app.use("/api/usuario", usuario_routes);
app.use("/api/vehiculo", vehiculo_routes);
app.use("/api/acceso-salida", acceso_salida_routes);
app.use("/api/celda", celda_routes);
app.use("/api/historial-parqueo", historial_parqueo_routes);
app.use("/api/incidencia", incidencia_routes);
app.use("/api/pico-placa", pico_placa_routes);
app.use("/api/reporte-incidencia", reporte_incidencia_routes);

// Ruta raiz
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Mi primera API funcionando correctamente",
    version: "1.0",
    endpoints: {
      perfil_usuario: {
        base: "/api/perfil-usuario",
        endpoints: {
          "POST /": "Crear perfil de usuario",
          "GET /": "Obtener todos los perfiles de usuario",
          "GET /: id_perfil_usuario": "Buscar perfil de usuario por ID",
          "GET /search/:term": "Buscar perfil de usuario por descripcion",
          "PUT /:id_perfil_usuario": "Actualizar perfil de usuario",
          "DELETE /:id_perfil_usuario": "Eliminar perfil de usuario",
        },
      },
      usuario: {
        base: "/api/usuario",
        endpoints: {
          "POST /": "Crear usuario",
        },
      },
      vehiculo: {
        base: "/api/vehiculo",
        endpoints: {
          "POST /": "Crear vehiculo",
        },
      },
      acceso_salida: {
        base: "/api/acceso-salida",
        endpoints: {
          "POST /": "Crear acceso_salida",
        },
      },
      celda: {
        base: "/api/celda",
        endpoints: {
          "POST /": "Crear celda",
        },
      },
      historial_parqueo: {
        base: "/api/historial-parqueo",
        endpoints: {
          "POST /": "Crear historial_parqueo",
        },
      },
      incidencia: {
        base: "/api/incidencia",
        endpoints: {
          "POST /": "Crear incidencia",
        },
      },
      pico_placa: {
        base: "/api/pico-placa",
        endpoints: {
          "POST /": "Crear pico_placa",
        },
      },
      reporte_incidencia: {
        base: "/api/reporte-incidencia",
        endpoints: {
          "POST /": "Crear reporte_incidencia",
        },
      },
    },
  });
});

// Configurar puerto
const port = process.env.PORT || 3000;

// Iniciar el servidor
const startServer = async () => {
  try {
    await connectDB();
    const server = app.listen(port, () => {
      console.log(`Servidor corriendo en puerto ${port}`);
      console.log(
        `Documentacion de la API disponible en: http://localhost:${port}`
      );
      console.log(`Entorno: ${process.env.NODE_ENV || "development"}`);
    });
  } catch (error) {
    console.error("Error al iniciar el servidor:", error);
    process.exit(1); // Sale con código de error
  }
};

startServer();

module.exports = app;
