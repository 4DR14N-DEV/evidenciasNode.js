# Proyecto Parqueadero

Una API REST para gestionar operaciones de parqueadero, incluyendo perfiles de usuario, vehículos, control de acceso, celdas de parqueo, historial, incidentes y restricciones de tráfico (pico y placa).

## Características

- Gestión de usuarios (perfiles y usuarios)
- Registro de vehículos
- Control de acceso y salida
- Gestión de celdas de parqueo
- Seguimiento del historial de parqueo
- Gestión de incidentes
- Gestión de restricciones de tráfico (pico y placa)
- Reportes de incidentes

## Tecnologías

- **Backend**: Node.js con Express.js
- **Base de Datos**: MongoDB con Mongoose
- **Otros**: CORS, dotenv

## Instalación

1. Clona el repositorio:

   ```bash
   git clone <url-del-repositorio>
   cd proyecto_parkin_lot
   ```

2. Instala las dependencias:

   ```bash
   npm install
   ```

3. Crea un archivo `.env` en el directorio raíz con las siguientes variables:

   ```env
   MONGODB_URI=tu_cadena_de_conexion_mongodb
   PORT=3000
   NODE_ENV=development
   ```

4. Inicia el servidor:
   - Desarrollo: `npm run dev`
   - Producción: `npm start`

El servidor se ejecutará en `http://localhost:3000` (o el puerto especificado en `.env`).

## Documentación de la API

Visita `http://localhost:3000` después de iniciar el servidor para ver los endpoints de la API y sus descripciones.

### Endpoints Principales

- `/api/perfil-usuario` - Gestión de perfiles de usuario
- `/api/usuario` - Gestión de usuarios
- `/api/vehiculo` - Gestión de vehículos
- `/api/acceso-salida` - Control de acceso y salida
- `/api/celda` - Gestión de celdas de parqueo
- `/api/historial-parqueo` - Historial de parqueo
- `/api/incidencia` - Gestión de incidentes
- `/api/pico-placa` - Gestión de restricciones de tráfico
- `/api/reporte-incidencia` - Reportes de incidentes

## Autor

Adrian Yesid Restrepo

## Licencia

MIT License
